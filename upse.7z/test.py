import glob, os, json, ntpath, sys
from pathlib import Path
from multiprocessing.pool import ThreadPool
import urllib.request

datalist = list()	
root_path = os.path.dirname(os.path.abspath(__file__))

def getExtention(path):
	if path == 'mrunal_ppt':
		return '.ppt'
	elif path == 'international_organisations':
		return '.docx'
	else:
		return '.pdf'

def prepareUrl(path, json):
	ext = getExtention(path)		
	for file in json:		
		storage = root_path + "\\output\\%s\\%s\\%s"%(file['Main Category'], file['Subjects'], file['Subject Folder'])
		fileName = file['url'] + ext
		url = "http://missionupsc.iaskumar.com/material/" + path + "/" + fileName	
		datalist.append({'url': url, 'folder': storage, 'fileName': fileName})

def downloadDate(pool):	
	i = 1;
	total = len(datalist)
	for data in datalist:
		p = ((i) / total) * 100	
		pool.apply_async(download, args=(data, p, i))
		i = i + 1
		if(i == 10):
			break
	pool.close()
	pool.join()	
	
def download(data, progress, count):
	url = data['url']
	folder = data['folder']
	fileName = data['fileName']	
	path = Path(folder)
	path.mkdir(parents=True, exist_ok=True)	
	fullpath = folder + "\\" + fileName
	if not os.path.isfile(fullpath): 
		urllib.request.urlretrieve(url, fullpath)
	sys.stdout.write("Progress: %d%%  downloading : %s  filename: %s\r" % (progress, count, fileName) )
	sys.stdout.flush()
	
		
def main():
	for file in glob.glob("assets\\*.json"):	
		with open(file) as json_data:
			d = json.load(json_data)			
			prepareUrl(os.path.splitext(ntpath.basename(file))[0], d)
		
	pool = ThreadPool(10)	
	downloadDate(pool)		
main()


